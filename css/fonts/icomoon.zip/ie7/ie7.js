/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-volume-mute': '&#xe615;',
		'icon-volume-low': '&#xe616;',
		'icon-volume-high': '&#xe617;',
		'icon-volume-mid': '&#xe618;',
		'icon-arrow-right': '&#xe61a;',
		'icon-pause': '&#xe614;',
		'icon-edit': '&#xe613;',
		'icon-close': '&#xe612;',
		'icon-play': '&#xe611;',
		'icon-search': '&#xe601;',
		'icon-caret-down': '&#xe602;',
		'icon-caret-up': '&#xe603;',
		'icon-email': '&#xe604;',
		'icon-facebook': '&#xe605;',
		'icon-google': '&#xe606;',
		'icon-linkedin': '&#xe608;',
		'icon-lock': '&#xe609;',
		'icon-thunderbolt': '&#xe60d;',
		'icon-time': '&#xe60e;',
		'icon-twitter': '&#xe60f;',
		'icon-user': '&#xe610;',
		'icon-presentation': '&#xe00e;',
		'icon-video': '&#xe011;',
		'icon-briefcase': '&#xe015;',
		'icon-global': '&#xe052;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
